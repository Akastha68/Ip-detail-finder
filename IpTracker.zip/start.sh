bash $HOME/storage/shared/Tools/IpTracker/banner/banner.sh
python $HOME/storage/shared/Tools/IpTracker/sound/music/song/main.py
