bash $HOME/Ip-detail-finder/banner/banner.sh
python3 $HOME/Ip-detail-finder/sound/music/song/main.py
