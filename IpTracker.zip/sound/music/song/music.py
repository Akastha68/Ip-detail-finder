import os

def Granted():
    os.system("mpv Granted.mp3")
    os.system("clear")

def Denied():
    os.system("mpv Denied.mp3")
    os.system("clear")

def Ladies():
    os.system("mpv Ladies.mp3")
    os.system("clear")

def Welcome():
    os.system("mpv Welcome.mp3")
    os.system('clear')
