import os
from rich import print
import time
def Rbanner():
    os.system("cls" if os.name == "nt" else "clear")
    
    # Animated colorful text effect
    colors = ["red"]
    for color in colors:
        os.system("cls" if os.name == "nt" else "clear")
        print(f'''
[bold {color}]●[bold {colors[(colors.index(color) + 1) % len(colors)]}] ●[bold {colors[(colors.index(color) + 2) % len(colors)]}] ●
      .---.        .-----------
     /     \  __  /    ------
    / /     \(  )/    -----
   //////   ' \/ `   ---
  //// / // :    : ---
 // /   /  /`    '--
//          //..\\\

       ====UU====UU====
           '//||\\`
[bold white]===========================≠≠≠≠==============
[bold white][[bold red]^[bold white]] [bold green] Author: Akash && Superficial AK \n[bold white][[bold red]^[bold white]] [bold green] Github: https://github.com/Akastha68 \n[bold white][[bold red]^[bold white]] [bold green] Telegram: https://t.me/Superficial_AK
[bold white]============================================= ''')



def Cbanner():
    os.system("cls" if os.name == "nt" else "clear")
    
    # Animated colorful text effect
    colors = ["cyan"]
    for color in colors:
        os.system("cls" if os.name == "nt" else "clear")
        print(f'''
[bold {color}]●[bold {colors[(colors.index(color) + 1) % len(colors)]}] ●[bold {colors[(colors.index(color) + 2) % len(colors)]}] ●
      .---.        .-----------
     /     \  __  /    ------
    / /     \(  )/    -----
   //////   ' \/ `   ---
  //// / // :    : ---
 // /   /  /`    '--
//          //..\\\

       ====UU====UU====
           '//||\\`
[bold white]===========================≠≠≠≠==============
[bold white][[bold red]^[bold white]] [bold green] Author: Akash & Superficial AK \n[bold white][[bold red]^[bold white]] [bold green] Github: github.com/Akastha68 \n[bold white][[bold red]^[bold white]] [bold green] Telegram: https://t.me/Superficial_AK
[bold white]============================================= ''')



def Bbanner():
    os.system("cls" if os.name == "nt" else "clear")
    
    # Animated colorful text effect
    colors = ["blue"]
    for color in colors:
        os.system("cls" if os.name == "nt" else "clear")
        print(f'''
[bold {color}]●[bold {colors[(colors.index(color) + 1) % len(colors)]}] ●[bold {colors[(colors.index(color) + 2) % len(colors)]}] ●
      .---.        .-----------
     /     \  __  /    ------
    / /     \(  )/    -----
   //////   ' \/ `   ---
  //// / // :    : ---
 // /   /  /`    '--
//          //..\\\

       ====UU====UU====
           '//||\\`
[bold white]===========================≠≠≠≠==============
[bold white][[bold red]^[bold white]] [bold green] Author: Akash & Superficial AK \n[bold white][[bold red]^[bold white]] [bold green] Github: github.com/Akastha68 \n[bold white][[bold red]^[bold white]] [bold green] Telegram: https://t.me/Superficial_AK
[bold white]============================================= ''')


def banner():
    os.system("cls" if os.name == "nt" else "clear")
    
    # Animated colorful text effect
    colors = ["red", "yellow", "green", "cyan", "blue", "magenta"]
    for color in colors:
        os.system("cls" if os.name == "nt" else "clear")
        print(f'''
[bold {color}]●[bold {colors[(colors.index(color) + 1) % len(colors)]}] ●[bold {colors[(colors.index(color) + 2) % len(colors)]}] ●
      .---.        .-----------
     /     \  __  /    ------
    / /     \(  )/    -----
   //////   ' \/ `   ---
  //// / // :    : ---
 // /   /  /`    '--
//          //..\\\

       ====UU====UU====
           '//||\\`
[bold white]===========================≠≠≠≠==============
[bold white][[bold red]^[bold white]] [bold green] Author: Akash & Superficial AK \n[bold white][[bold red]^[bold white]] [bold green] Github: https://github.com/Akastha68 \n[bold white][[bold red]^[bold white]] [bold green] Telegram: https://t.me/Superficial_AK
[bold white]============================================= ''')
        time.sleep(0.5)
