bash banner.sh
pkg update 
pkg upgrade
apt-get update
apt-get upgrade
pkg install mpv
apt install mpv
pkg install git
apt install git
pkg install figlet
pip install colorama
pip install rich
pip install requests
clear

